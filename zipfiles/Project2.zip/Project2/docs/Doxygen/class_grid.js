var class_grid =
[
    [ "Grid", "class_grid.html#a2a809d16ae2ba160bd3a0e7a8f6406df", null ],
    [ "Grid", "class_grid.html#a4ac9ff4f63552b4c61ff90fcb35ad66c", null ],
    [ "~Grid", "class_grid.html#a3661d0a7f998caaaf8627d7a67072116", null ],
    [ "getCols", "class_grid.html#a3722889bf09d087ab6ced7f2311ec0b9", null ],
    [ "getnSquares", "class_grid.html#a13c38ac97957b2651260fd49de51f542", null ],
    [ "getPositionValue", "class_grid.html#a57287f4139d60cd76904e2fd64ca3f87", null ],
    [ "getPositionX", "class_grid.html#acb543c2552743f9e54e94dc7d1e21137", null ],
    [ "getPositionY", "class_grid.html#ada3d10f19dd33168869d0314e552b9cf", null ],
    [ "getRows", "class_grid.html#aa9397afb775457f87b9096acf6082383", null ],
    [ "printP", "class_grid.html#a9715b7d5837d1161f8104896a1795731", null ],
    [ "setCols", "class_grid.html#add5e3550ba695a2124bb4dbcad3789c7", null ],
    [ "setPositionsNew", "class_grid.html#aca195e84b5e33e41603931fe15452d6b", null ],
    [ "setPositionValue", "class_grid.html#a919da7669a59db10651cd0267a31820e", null ],
    [ "setPositionX", "class_grid.html#abbed297bc9129c339dbc5813923e25bb", null ],
    [ "setPositionY", "class_grid.html#ace6bd48c97fa2c8c1e9c7c72219b8ebb", null ],
    [ "setRows", "class_grid.html#a02c6facf4d6c74d3e0a8b6554e108baa", null ],
    [ "gridsFriend", "class_grid.html#a3a5c238753b6ad4794492f0dd014bb5f", null ]
];