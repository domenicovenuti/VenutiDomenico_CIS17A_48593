var class_players_score =
[
    [ "PlayersScore", "class_players_score.html#a7aa19ef3a26c887b9acc199c7de61b68", null ],
    [ "getP1", "class_players_score.html#a0b8abea221859675c45564fa7f4d5888", null ],
    [ "getP2", "class_players_score.html#a4ee5badcebd2eabe8105585312d9e285", null ],
    [ "getPlayer1n", "class_players_score.html#aa3ccd9e65a30e307c652769d0b9775d7", null ],
    [ "getScore1", "class_players_score.html#abbf40ec4d340a0d8ddac1aac901cb280", null ],
    [ "getWinn", "class_players_score.html#a3081f07fbb7905b68f931b0c0c96f79d", null ],
    [ "operator+", "class_players_score.html#ad402235aea879e61ea0e656faaf7c05c", null ],
    [ "operator-", "class_players_score.html#a7193efc2b4b72072e9015f6806f0f047", null ],
    [ "operator/", "class_players_score.html#ac4641550ffc035855a8b1d409bbee885", null ],
    [ "setP1", "class_players_score.html#a43a69f5b86d23a84528635e5a035bb4f", null ],
    [ "setP2", "class_players_score.html#aec71190581505741c3d6cc93c6b9b1d5", null ],
    [ "setPlayer1n", "class_players_score.html#a2f063b1693ed91a4050a5542d4c96d53", null ],
    [ "setScore1", "class_players_score.html#a60f2dddc5c8963e8749eaec34ec70707", null ]
];