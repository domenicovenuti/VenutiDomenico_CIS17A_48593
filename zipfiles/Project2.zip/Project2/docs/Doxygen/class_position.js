var class_position =
[
    [ "Position", "class_position.html#a369a577425f8ba02e8750d04b6a088db", null ],
    [ "getnSquares", "class_position.html#a42565c2238f2195a0cfed6518490be23", null ],
    [ "getValue", "class_position.html#a47b2cdc6680ebd28ef4fdcfc7f682aad", null ],
    [ "getX", "class_position.html#aec07bdc14874f47cd1dc675d864f49a2", null ],
    [ "getY", "class_position.html#aecedcf0af53e559ccde18432f20d1a37", null ],
    [ "setValue", "class_position.html#adef2e677840a9b7f457887ca7d4c6836", null ],
    [ "setX", "class_position.html#a3668a9bf0bc2b7be11cf57d1ea39af0c", null ],
    [ "setY", "class_position.html#ae4bdefa8d403050f81aecb1b1a856852", null ]
];