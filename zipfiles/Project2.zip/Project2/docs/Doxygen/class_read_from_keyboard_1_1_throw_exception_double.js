var class_read_from_keyboard_1_1_throw_exception_double =
[
    [ "ThrowExceptionDouble", "class_read_from_keyboard_1_1_throw_exception_double.html#a2208511ea6b835c8d1f1a6602acde51e", null ]
];