var class_base =
[
    [ "Base", "class_base.html#a5ffe0568374d8b9b4c4ec32953fd6453", null ],
    [ "getBoardSize", "class_base.html#a8984ab540346107b434361e66f159bcc", null ],
    [ "getTextMenu", "class_base.html#a7eaae52eaa9c5e83b6dae060563bc22c", null ],
    [ "gettGamesPlayes", "class_base.html#ad9cecbb8e250a93f825f1ad0597b0445", null ],
    [ "setBoardSize", "class_base.html#a325ba1711ea704377eca6bbdc1809ac0", null ],
    [ "settGamesPlayed", "class_base.html#ae8f87e0532eade15e846bde9da87ff72", null ],
    [ "boardsize", "class_base.html#a8a1e642263e3ce09d80da9279a2202dd", null ]
];