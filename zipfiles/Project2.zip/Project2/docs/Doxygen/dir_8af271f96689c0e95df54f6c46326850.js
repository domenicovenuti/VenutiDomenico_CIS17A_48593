var dir_8af271f96689c0e95df54f6c46326850 =
[
    [ "Connect_4_Board_Game_V1.5.0", "dir_e456305307416e435566fcd393b4ebc0.html", "dir_e456305307416e435566fcd393b4ebc0" ]
];