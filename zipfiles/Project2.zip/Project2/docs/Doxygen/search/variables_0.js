var searchData=
[
  ['boardsize_0',['boardsize',['../class_base.html#a8a1e642263e3ce09d80da9279a2202dd',1,'Base::boardsize()'],['../main_8cpp.html#a7fa3883e7f89d4097330e49a08a5524b',1,'boardsize():&#160;main.cpp']]]
];
