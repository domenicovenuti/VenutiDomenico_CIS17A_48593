var searchData=
[
  ['player_0',['player',['../main_8cpp.html#ad3e2183fcffb1e747e91084774d0d77b',1,'main.cpp']]],
  ['player1_1',['player1',['../main_8cpp.html#a8ba95adc6884231ea94d3228f6d973d5',1,'main.cpp']]],
  ['player2_2',['player2',['../main_8cpp.html#a7e72bb1c6167f2ae66b2b40cb00fc2ce',1,'main.cpp']]]
];
