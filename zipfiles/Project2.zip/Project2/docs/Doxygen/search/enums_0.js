var searchData=
[
  ['boardsize_0',['Boardsize',['../main_8cpp.html#ab081acfff861a876aa7834b4b52f61ba',1,'main.cpp']]]
];
