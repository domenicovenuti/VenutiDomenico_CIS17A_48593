var searchData=
[
  ['nobodywon_0',['nobodyWon',['../main_8cpp.html#a28b028dac20c3b4a594fda2b99733a31',1,'main.cpp']]],
  ['none_1',['NONE',['../main_8cpp.html#a9c8780378078e51e7c9041cbac392db9ac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'main.cpp']]]
];
