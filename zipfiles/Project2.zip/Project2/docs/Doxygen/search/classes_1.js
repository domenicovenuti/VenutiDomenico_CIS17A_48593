var searchData=
[
  ['derived_0',['Derived',['../class_derived.html',1,'']]]
];
