var searchData=
[
  ['gridsfriend_0',['gridsFriend',['../class_grid.html#a3a5c238753b6ad4794492f0dd014bb5f',1,'Grid']]]
];
