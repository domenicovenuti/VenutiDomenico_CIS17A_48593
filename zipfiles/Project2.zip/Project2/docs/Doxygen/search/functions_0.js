var searchData=
[
  ['base_0',['Base',['../class_base.html#a5ffe0568374d8b9b4c4ec32953fd6453',1,'Base']]]
];
