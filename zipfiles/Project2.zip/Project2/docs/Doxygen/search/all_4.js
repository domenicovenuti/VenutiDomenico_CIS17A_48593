var searchData=
[
  ['evaluate135degrees_0',['evaluate135Degrees',['../main_8cpp.html#a2716decbd7da60584bd9fdaf2c49af7e',1,'main.cpp']]],
  ['evaluate45degrees_1',['evaluate45Degrees',['../main_8cpp.html#a46fd56585109d815523fbf969363cf39',1,'main.cpp']]],
  ['evaluatehorizontal_2',['evaluateHorizontal',['../main_8cpp.html#a00d739bcb5e238df1343770569325444',1,'main.cpp']]],
  ['evaluatevertical_3',['evaluateVertical',['../main_8cpp.html#a40e5d936655f6906e71fa01d7da7da1f',1,'main.cpp']]]
];
