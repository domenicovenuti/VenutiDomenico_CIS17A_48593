var searchData=
[
  ['derived_0',['Derived',['../class_derived.html',1,'Derived'],['../class_derived.html#a62feae88ad8218ab29620f2cebb1447b',1,'Derived::Derived()']]],
  ['derived_2eh_1',['Derived.h',['../_derived_8h.html',1,'']]]
];
