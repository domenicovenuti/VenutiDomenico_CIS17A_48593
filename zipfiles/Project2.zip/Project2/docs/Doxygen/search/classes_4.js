var searchData=
[
  ['readfromkeyboard_0',['ReadFromKeyboard',['../class_read_from_keyboard.html',1,'']]]
];
