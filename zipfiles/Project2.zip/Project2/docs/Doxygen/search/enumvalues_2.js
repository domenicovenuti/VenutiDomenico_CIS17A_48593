var searchData=
[
  ['player1_0',['PLAYER1',['../main_8cpp.html#a9c8780378078e51e7c9041cbac392db9a77d1b58e26a2a3d61ce38e09764cbc19',1,'main.cpp']]],
  ['player2_1',['PLAYER2',['../main_8cpp.html#a9c8780378078e51e7c9041cbac392db9a32a327d66c65387bb124f6c9408ff90b',1,'main.cpp']]],
  ['playervscomputer_2',['PLAYERVSCOMPUTER',['../main_8cpp.html#a9f541007c748be1829b95137b27f2fd7ac76541dfd370b53a5488373df4cf4d75',1,'main.cpp']]],
  ['playervsplayer_3',['PLAYERVSPLAYER',['../main_8cpp.html#a9f541007c748be1829b95137b27f2fd7abcc818beed49e868c4dae55c920abd15',1,'main.cpp']]]
];
