var searchData=
[
  ['player_0',['Player',['../main_8cpp.html#a9c8780378078e51e7c9041cbac392db9',1,'main.cpp']]]
];
