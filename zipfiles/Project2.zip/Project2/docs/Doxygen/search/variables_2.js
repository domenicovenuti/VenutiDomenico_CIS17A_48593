var searchData=
[
  ['max_5farray_0',['MAX_ARRAY',['../main_8cpp.html#abadcafca2b4ae718da114c8bfde51421',1,'main.cpp']]],
  ['max_5fcols_1',['MAX_COLS',['../main_8cpp.html#a1eb290036db0f4b16ad807590d0ec660',1,'main.cpp']]],
  ['max_5frows_2',['MAX_ROWS',['../main_8cpp.html#a4851e379e6f4fbcb7c318decd6743932',1,'main.cpp']]],
  ['max_5fsize_3',['MAX_SIZE',['../_grid_8h.html#a755a370812a5c314712719ca48af8261',1,'Grid.h']]]
];
