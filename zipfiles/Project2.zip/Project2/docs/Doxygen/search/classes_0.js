var searchData=
[
  ['base_0',['Base',['../class_base.html',1,'']]]
];
