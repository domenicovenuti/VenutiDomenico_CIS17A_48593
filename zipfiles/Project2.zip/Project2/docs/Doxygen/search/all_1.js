var searchData=
[
  ['base_0',['Base',['../class_base.html',1,'Base'],['../class_base.html#a5ffe0568374d8b9b4c4ec32953fd6453',1,'Base::Base()']]],
  ['base_2ecpp_1',['Base.cpp',['../_base_8cpp.html',1,'']]],
  ['base_2eh_2',['Base.h',['../_base_8h.html',1,'']]],
  ['base_2eo_2ed_3',['Base.o.d',['../_base_8o_8d.html',1,'']]],
  ['boardsize_4',['boardsize',['../class_base.html#a8a1e642263e3ce09d80da9279a2202dd',1,'Base']]],
  ['boardsize_5',['Boardsize',['../main_8cpp.html#ab081acfff861a876aa7834b4b52f61ba',1,'main.cpp']]],
  ['boardsize_6',['boardsize',['../main_8cpp.html#a7fa3883e7f89d4097330e49a08a5524b',1,'main.cpp']]]
];
