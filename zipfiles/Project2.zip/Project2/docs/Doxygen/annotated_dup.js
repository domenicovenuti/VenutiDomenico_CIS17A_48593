var annotated_dup =
[
    [ "Base", "class_base.html", "class_base" ],
    [ "Derived", "class_derived.html", "class_derived" ],
    [ "Grid", "class_grid.html", "class_grid" ],
    [ "PlayersScore", "class_players_score.html", "class_players_score" ],
    [ "Position", "class_position.html", "class_position" ],
    [ "ReadFromKeyboard", "class_read_from_keyboard.html", "class_read_from_keyboard" ]
];