var class_derived =
[
    [ "Derived", "class_derived.html#a62feae88ad8218ab29620f2cebb1447b", null ],
    [ "getTextMenu", "class_derived.html#a2f3401ca1bf1724ec5c73563451e5440", null ]
];