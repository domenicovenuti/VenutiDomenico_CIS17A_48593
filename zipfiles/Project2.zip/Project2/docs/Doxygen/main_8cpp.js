var main_8cpp =
[
    [ "Boardsize", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61ba", [
      [ "CLASSIC7X6", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61baa9cdab0a0735203094f97a6cd2cc08307", null ],
      [ "X54", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61baaedd32f637acca514639ca4dab396cbd3", null ],
      [ "X65", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61baa33405195aba5ea8cda41ad47dc2dbbfd", null ],
      [ "X87", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61baae97a159395d7a09e5f0bf43708eb17b9", null ],
      [ "X97", "main_8cpp.html#ab081acfff861a876aa7834b4b52f61baa2e4edac9a332bdd413a1ca32f26c0d2e", null ]
    ] ],
    [ "Games", "main_8cpp.html#a9f541007c748be1829b95137b27f2fd7", [
      [ "PLAYERVSPLAYER", "main_8cpp.html#a9f541007c748be1829b95137b27f2fd7abcc818beed49e868c4dae55c920abd15", null ],
      [ "PLAYERVSCOMPUTER", "main_8cpp.html#a9f541007c748be1829b95137b27f2fd7ac76541dfd370b53a5488373df4cf4d75", null ],
      [ "RANDOM", "main_8cpp.html#a9f541007c748be1829b95137b27f2fd7aa2b65445a3a16f164c5e811064d75726", null ]
    ] ],
    [ "Player", "main_8cpp.html#a9c8780378078e51e7c9041cbac392db9", [
      [ "NONE", "main_8cpp.html#a9c8780378078e51e7c9041cbac392db9ac157bdf0b85a40d2619cbc8bc1ae5fe2", null ],
      [ "PLAYER1", "main_8cpp.html#a9c8780378078e51e7c9041cbac392db9a77d1b58e26a2a3d61ce38e09764cbc19", null ],
      [ "PLAYER2", "main_8cpp.html#a9c8780378078e51e7c9041cbac392db9a32a327d66c65387bb124f6c9408ff90b", null ]
    ] ],
    [ "evaluate135Degrees", "main_8cpp.html#a2716decbd7da60584bd9fdaf2c49af7e", null ],
    [ "evaluate45Degrees", "main_8cpp.html#a46fd56585109d815523fbf969363cf39", null ],
    [ "evaluateHorizontal", "main_8cpp.html#a00d739bcb5e238df1343770569325444", null ],
    [ "evaluateVertical", "main_8cpp.html#a40e5d936655f6906e71fa01d7da7da1f", null ],
    [ "gameLogic", "main_8cpp.html#a3c9672ec1d3bda17b89fbee21f8ebab1", null ],
    [ "gameTypeMenu", "main_8cpp.html#ae11711b0339eaa41900ab69b27aeab37", null ],
    [ "gridsFriend", "main_8cpp.html#a3a5c238753b6ad4794492f0dd014bb5f", null ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "mainMenu", "main_8cpp.html#a1ba4487c7e8d73bfe3595c0521ee9c98", null ],
    [ "nobodyWon", "main_8cpp.html#a28b028dac20c3b4a594fda2b99733a31", null ],
    [ "overloadOperators", "main_8cpp.html#af3e513416ad04719abd165798a24dd1c", null ],
    [ "playerName", "main_8cpp.html#a8a98813db954625c8d8cab3a01fda780", null ],
    [ "printGrid", "main_8cpp.html#a5ff9aafc6961a8e54c00b5a01e31770c", null ],
    [ "printPlayerOptions", "main_8cpp.html#a934b23c21f67785fe74cc84e4c1a3879", null ],
    [ "readBinaryFile", "main_8cpp.html#a139feed5cbaea376fa823954d86deab6", null ],
    [ "readOptionfromKeyboard", "main_8cpp.html#ad508a938b996c70e52c1dd14970540fd", null ],
    [ "showScores", "main_8cpp.html#a5da34b1d747f26dab8795ccebb1b4798", null ],
    [ "someoneWon", "main_8cpp.html#a4d2c9523ac6587918228de1d05d7969c", null ],
    [ "trim", "main_8cpp.html#ab2e21c4ffa4eb42b8edce26a2568887c", null ],
    [ "winLogic", "main_8cpp.html#a41cfa06239c17474d09f9a3c7dad4cca", null ],
    [ "writeBinaryFile", "main_8cpp.html#ae9d494345be14aac7ceeead71a48203d", null ],
    [ "boardsize", "main_8cpp.html#a7fa3883e7f89d4097330e49a08a5524b", null ],
    [ "games", "main_8cpp.html#a25f02b9534cc34fbe14cdd556cb13d01", null ],
    [ "MAX_ARRAY", "main_8cpp.html#abadcafca2b4ae718da114c8bfde51421", null ],
    [ "MAX_COLS", "main_8cpp.html#a1eb290036db0f4b16ad807590d0ec660", null ],
    [ "MAX_ROWS", "main_8cpp.html#a4851e379e6f4fbcb7c318decd6743932", null ],
    [ "player", "main_8cpp.html#ad3e2183fcffb1e747e91084774d0d77b", null ],
    [ "player1", "main_8cpp.html#a8ba95adc6884231ea94d3228f6d973d5", null ],
    [ "player2", "main_8cpp.html#a7e72bb1c6167f2ae66b2b40cb00fc2ce", null ]
];