var dir_30bb516d5bb800bd68023912f8f0a86f =
[
    [ "Connect_4_Board_Game_V1.5.0", "dir_1956a9916c5524f55bd8d6660a034462.html", "dir_1956a9916c5524f55bd8d6660a034462" ]
];