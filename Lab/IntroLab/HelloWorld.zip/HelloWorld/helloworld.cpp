/* 
 * File: helloworld.cpp
 * Author: Domenico Venuti
 * Created on September 6, 2021 - Assignment_1, 4:00 PM
 * Purpose:  CIS-17A - 48591 - IntroLab (HelloWorld Program)
 */

#include<iostream>

using namespace std;

int main()
{
    cout<<"HelloWord";
    return 0;
}

